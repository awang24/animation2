package cs3500.animator.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import cs3500.animator.model.IAnimationModel;
import cs3500.animator.model.animation.Animations;
import cs3500.animator.model.shape.CreateShapeVisitor;
import cs3500.animator.model.shape.Shapes;
import cs3500.animator.view.IView;


/**
 * Represents the controller for the interactive view that combines the functionality of the SVG
 * view and Visual view.
 */
public class InteractiveController implements IAnimationController, ActionListener {

  private IAnimationModel model;
  private IView view;
  private double tempo;
  private boolean isAnimationStarted;
  private String filename;

  /**
   * Create an instance of an InteractiveController.
   * @param model      The model that the controller uses
   * @param view       The view that the controller uses
   * @param tempo      The speed at which the animation is played
   * @param filename   The filename that the controller writes out to
   */
  public InteractiveController(IAnimationModel model, IView view, double tempo, String filename) {
    this.model = model;
    this.view = view;
    this.tempo = tempo;
    this.isAnimationStarted = false;
    this.filename = filename;
  }

  @Override
  public void start() {
    this.view.setPlayButtonListener(this);
    this.view.makeVisible();
  }

  public void go() {


    //Offer SVG functionality
    this.view.writeOut(filename);

    //Offer Visual functionality
    this.isAnimationStarted = true;
    long startTime = System.currentTimeMillis();
    long timeElapsed = 0;

    double secondsElapsed = 0;
    double unitsElapsed = 0;
    List<Animations> animations = model.getAnimations();
    List<Shapes> shapes = model.getShapes();

    List<Shapes> newListShapes = new ArrayList<Shapes>();

    for (int i = 0; i < shapes.size(); i++) {
      Shapes newShape = shapes.get(i).accept(new CreateShapeVisitor());
      newListShapes.add(newShape);
    }

    while (this.isAnimationStarted) {

      timeElapsed = System.currentTimeMillis() - startTime;
      secondsElapsed = timeElapsed / 1000.0;
      unitsElapsed = secondsElapsed * tempo;

      if (unitsElapsed == 100) {
        this.isAnimationStarted = false;
      }

      for (int i = 0; i < animations.size(); i++) {
        Animations currentAnimation = animations.get(i);
        Shapes animationShape = currentAnimation.getShape();
        for (int j = 0; j < newListShapes.size(); j++) {
          Shapes currentShape = newListShapes.get(j);
          if (currentShape.getName().equals(animationShape.getName())) {
            currentAnimation.setShape(currentShape);
          }
        }
      }

      for (int i = 0; i < animations.size(); i++) {
        Animations current = animations.get(i);
        int start = current.getStart();
        int end = current.getEnd();

        if (start <= unitsElapsed && end >= unitsElapsed) {
          current.animate(unitsElapsed);
          this.view.setShapes(newListShapes);
          this.view.refresh();
        }
      }
      this.view.makeVisible();
    }
  }

  @Override
  public void actionPerformed(ActionEvent e) {
    this.go();
  }
}
