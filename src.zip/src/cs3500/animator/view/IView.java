package cs3500.animator.view;

import java.awt.event.ActionListener;
import java.util.List;

import cs3500.animator.model.IAnimationModel;
import cs3500.animator.model.shape.Shapes;

/**
 * Represents a general interface for a view. Encapsulates all types of views. Methods throw
 * UnsupportedOperationException if the individual views does not need the functionality
 */
public interface IView {

  /**
   * Gets the string representation/text view of the animation.
   *
   * @return string representation of the animations and shapes
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  String getDescription();

  /**
   * Writes the string description out to a given text file name.
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  void writeOut(String fileName);

  /**
   * Returns the model that the view is using.
   *
   * @return the model that the view is using
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  IAnimationModel getModel();

  /**
   * Returns the tempo of the view.
   *
   * @return the tempo of the view
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  double getTempo();

  /**
   * Makes the view visible.
   * @throws UnsupportedOperationException if the view does not need the functionality
   **/
  void makeVisible();

  /**
   * Transmit an error message to the view, in case the command could not be processed correctly.
   *
   * @param error String error message
   * @throws UnsupportedOperationException if the view does not need the functionality
   **/
  void showErrorMessage(String error);

  /**
   * Signal the view to draw itself.
   * @throws UnsupportedOperationException if the view does not need the functionality
   **/
  void refresh();

  /**
   * Sets the list of shapes to see.
   *
   * @param shapes List of shapes to add
   * @throws UnsupportedOperationException if the view does not need the functionality
   **/
  void setShapes(List<Shapes> shapes);

  /**
   * Provide the view with an actionListener for the play button which starts the animation
   * @param actionEvent    The actionListener for the play button
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  void setPlayButtonListener(ActionListener actionEvent);

  /**
   * Provide the view with an actionListener for the pause button which pauses the animation
   * @param actionEvent    The actionListener for the pause button
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  void setPauseButtonListener(ActionListener actionEvent);

  /**
   * Provide the view with an actionListener for the restart button which restarts the animation
   * @param actionEvent    The actionListener for the restart button
   * @throws UnsupportedOperationException if the view does not need the functionality
   */
  void setRestartButtonListener(ActionListener actionEvent);
}
