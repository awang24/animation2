package cs3500.animator.view;

import java.awt.*;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Dimension;

import cs3500.animator.model.IAnimationModel;
import cs3500.animator.model.animation.Animations;
import cs3500.animator.model.shape.Shapes;

/**
 * A class that represents a view for an interactive view.
 */
public class InteractiveView extends JFrame implements IView {
  private IAnimationModel model;
  private double tempo;
  private JButton playButton, pauseButton, restartButton, speedButton, fileButton;
  private JPanel buttonPanel;
  private JTextField speedInput;
  private JTextField fileInput;



  private AnimationPanel animatePanel;
  private List<Shapes> shapes;

  /**
   * Constructs a {@code InteractiveView} object.
   *
   * @param tempo represents the speed at which the animation occurs
   * @param model model that view will use
   */
  public InteractiveView(double tempo, IAnimationModel model) {
    super();

    this.model = model;
    this.tempo = tempo;

    this.shapes = model.getShapes();//shapes;
    this.setTitle("Simple Animation");
    this.setSize(700, 700);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    animatePanel = new AnimationPanel();
    animatePanel.setPreferredSize(new Dimension(700, 700));

    animatePanel.setShapes(shapes);

    JScrollPane scrollPane = new JScrollPane(animatePanel);
    scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
    scrollPane.setBounds(50, 30, 300, 50);

    this.add(scrollPane, BorderLayout.CENTER);

    //button panel
    buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());
    this.add(buttonPanel, BorderLayout.SOUTH);

    //buttons
    playButton = new JButton("PLAY");
    buttonPanel.add(playButton);

    pauseButton = new JButton("PAUSE");
    buttonPanel.add(pauseButton);
    restartButton = new JButton("RESTART");
    buttonPanel.add(restartButton);

    //input textfield
    speedInput = new JTextField(3);
    buttonPanel.add(speedInput);
    speedButton = new JButton("CHANGE SPEED");
    buttonPanel.add(speedButton);
    fileInput = new JTextField(10);
    buttonPanel.add(fileInput);
    fileButton = new JButton("SET FILE");
    buttonPanel.add(fileButton);


    this.pack();
  }

  @Override
  public String getDescription() {
    List<Shapes> shapes = this.getModel().getShapes();
    List<Animations> animations = this.getModel().getAnimations();
    double tempo = this.getTempo();

    String state = "<svg width=\"700\" height=\"500\" version=\"1.1\"\n"
            + "xmlns=\"http://www.w3.org/2000/svg\">\n";

    for (int i = 0; i < shapes.size(); i++) {
      Shapes currentShape = shapes.get(i);
      state += currentShape.toSVGTag();
      for (int j = 0; j < animations.size(); j++) {
        Animations currentA = animations.get(j);
        Shapes currentS = currentA.getShape();
        if (currentShape.getName().equals(currentS.getName())) {
          state += currentA.toSVGTag(this.getTempo());
        }
      }
      state += currentShape.svgEndTag() + "\n";
    }
    state += "</svg>";

    return state;
  }

  @Override
  public void makeVisible() {
    this.setVisible(true);
  }

  @Override
  public void setPlayButtonListener(ActionListener actionEvent) {
    playButton.addActionListener(actionEvent);
  }

  @Override
  public void setPauseButtonListener(ActionListener actionEvent) {
    pauseButton.addActionListener(actionEvent);
  }

  @Override
  public void setRestartButtonListener(ActionListener actionEvent) {
    restartButton.addActionListener(actionEvent);
  }



  @Override
  public void showErrorMessage(String error) {
    JOptionPane.showMessageDialog(this, error, "Error", JOptionPane.ERROR_MESSAGE);
  }

  @Override
  public void refresh() {
    this.repaint();
  }

  @Override
  public void setShapes(List<Shapes> shapes) {
    this.shapes = shapes;
    animatePanel.setShapes(shapes);
  }

  @Override
  public void writeOut(String fileName) {
    String description = this.getDescription();
    try {
      BufferedWriter output = null;
      if (fileName.equals("System.out")) {
        output = new BufferedWriter(new OutputStreamWriter(System.out));
      } else {
        File file = new File(fileName);
        output = new BufferedWriter(new FileWriter(file));
      }
      output.write(description);
      output.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  @Override
  public IAnimationModel getModel() {
    return this.model;
  }

  @Override
  public double getTempo() {
    return this.tempo;
  }
}
