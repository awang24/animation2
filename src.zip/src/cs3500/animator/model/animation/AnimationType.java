package cs3500.animator.model.animation;

/**
 * Different forms of animations implemented.
 */
public enum AnimationType {
  MOVE, CHANGECOLOR, CHANGEDIMENSION;

}
